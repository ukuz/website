This Hugo theme was ported from [Ivy](https://github.com/MJGrey/ivy) (its [original repo](https://github.com/dmulholland/ivy) is no longer accessible), a minimalist website generator built in Python. I don't have time to document it. You have to read the source code to understand what it can do. Like Ivy, this theme is also released under [the Unlicense](https://en.wikipedia.org/wiki/Unlicense), which basically means you just do whatever you want.

[![Screenshot](https://github.com/yihui/hugo-ivy/raw/master/images/screenshot.png)](https://ivy.yihui.org)

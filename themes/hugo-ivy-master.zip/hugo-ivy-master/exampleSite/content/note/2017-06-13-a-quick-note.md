---
title: A Quick Note on Two Beautiful Websites
author: Yihui Xie
date: '2017-06-13'
categories:
  - Example
slug: a-quick-note
---

To me, the two most impressive websites based on **blogdown** are:

1. [Rob J Hyndman](https://robjhyndman.com)'s personal website.
1. [Live Free or Dichotomize](http://livefreeordichotomize.com) by Lucy and Nick _et al_.

I'm sure there will be more.
